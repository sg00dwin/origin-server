
$config = {
  :dns => {
    :server => '127.0.0.1',
    :port => '10053',
    :keyname => 'example.com',
    :keyvalue => 'H6NDDnTbNpcBrUM5c4BJtohyK2uuZ5Oi6jxg3ME+RJsNl5Wl2B87oL12YxWUR3Gp7FdZQojTKBSfs5ZjghYxGw==',
    :zone => "example.com"
  },

  :cdk => {
    :domain_suffix => "example.com"
  }
}
